import java.io.PrintWriter;
import java.util.Scanner;

public class Book {
    private String title;
    private String author;
    private int numCopies;

    public Book(Scanner fileLoader) {
        fileLoader.useDelimiter("/|\n");
        title = fileLoader.next();
        author = fileLoader.next();
        numCopies = fileLoader.nextInt();
        fileLoader.nextLine();
    }

    public Book(String bookTitle, String bookAuthor, int bookCopies) {
        title = bookTitle;
        author = bookAuthor;
        numCopies = bookCopies;
    }

    public String getTitle() { return title; }
    public String getAuthor() { return author; }
    public int getNumCopies() { return numCopies; }

    public void increaseCopiesBy(int num) {
        if(num > 0) {
            numCopies += num;
        }
    }

    public boolean decreaseCopiesBy(int num) {
        if(num > 0 && num < numCopies) {
            numCopies -= num;
        } else if(num >= numCopies) {
            numCopies = 0;
            return true;
        }
        return false;
    }

    public void save(PrintWriter fileSaver) {
        if(numCopies > 0) {
            fileSaver.println(title + " " + author + " " + numCopies);
        }
    }
}

