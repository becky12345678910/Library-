import java.io.*;
import java.util.Scanner;

public class Library {
    Book[] books;
    int numBooks;
    String booksFile = "src/books.txt";
    Scanner input = new Scanner(System.in);

    public Library() {
        Scanner bookLoader = null;
        try {
            File booksTxt = new File(booksFile);
            bookLoader = new Scanner(booksTxt);
            if(bookLoader.hasNext() == false) {
                System.err.println("System File Not Found: Assuming First System Run");
            }
            numBooks = bookLoader.nextInt();
            bookLoader.nextLine();

            books = new Book[numBooks];
            for (int i = 0; i < numBooks; i++) {
                books[i] = new Book(bookLoader);
            }
            bookLoader.close();
        } catch(Exception e) {
            e.printStackTrace();
            System.err.println("Error Loading Books. Aborting program.");
            System.exit(-1);
        } finally {
            if(bookLoader != null) bookLoader.close();
        }
    }

    public void printSelections() {
        System.out.println("Possible commands are:");
        System.out.println("\t(1) Checkout");
        System.out.println("\t(2) Checkin");
        System.out.println("\t(3) Check for Availability");
        System.out.println("\t(4) List All Books");
        System.out.println("\t(5) Add a new Book");
        System.out.println("\t(6) Delete a lost Book");
        System.out.println("\t(7) Quit");
    }

    public void checkout() {
        int index = getBookIndex();
        if(index >= 0) {
            if(books[index].getNumCopies() > 0) {     // If book is available
                books[index].decreaseCopiesBy(1);
            } else {
                System.out.println("No copies are available");
            }
        }
    }

    public void checkin() {
        int index = getBookIndex();
        if(index >= 0) {
            books[index].increaseCopiesBy(1);
        }
    }

    public void getAvailability() {
        int index = getBookIndex();
        if(index >= 0) {
            System.out.println("There are " + books[index].getNumCopies() + " copies available");
        }
    }

    public void addNewBook() {
        System.out.println("Enter the title of the book: ");
        String title = input.nextLine();
        System.out.println("Enter the author of the book: ");
        String author = input.nextLine();
        System.out.println("Enter the number of copies: ");
        int numCopies = 0;
        while(numCopies <= 0) {
            try {
                numCopies = input.nextInt();
                if (numCopies <= 0) throw new Exception();
            } catch (Exception e) {
                System.err.println("Invalid number");
                input.nextLine();
            }
        }
        int index = findBookByTitle(title);
        if(index >= 0) {
            System.out.println("Adding additional copy");
            books[index].increaseCopiesBy(numCopies);
        } else {
            if(numBooks == books.length) {
                resizeArray();
            }
            books[numBooks] = new Book(title, author, numCopies);
            numBooks++;
        }
    }

    public void deleteBook() {
        int index = getBookIndex();
        if(index >= 0) {
            for(;index < numBooks - 1; index++) {
                books[index] = books[index + 1];
            }
            numBooks--;
            System.out.println("Book deleted successfully");
        }
    }

    public void save() {
        boolean attemptSave = true;
        while(attemptSave) {
            try {
                FileWriter fw = new FileWriter(booksFile);
                BufferedWriter bw = new BufferedWriter(fw);
                PrintWriter outFile = new PrintWriter(bw);

                outFile.println(numBooks);
                for(int i = 0; i < numBooks; i++) {
                    books[i].save(outFile);
                }

                outFile.close();
                attemptSave = false;
            } catch (IOException e) {
                System.err.println("Fatal Error: IOException when writing to file. Try Again? (y/n)");
                Scanner input = new Scanner(System.in);
                if(input.next().toLowerCase().equals("n")) {
                    attemptSave = false;
                }
            }
        }
    }

    public void listBooks() {
        for(int i = 0; i < books.length; i++) {
            System.out.println(books[i].getTitle() + " by " + books[i].getAuthor() + " with " + books[i].getNumCopies() + " available");
        }
    }

    private int getBookIndex() {
        System.out.println("Enter title or author:");
        String bookDesc = input.nextLine();

        int index = findBookByTitle(bookDesc);
        if (index >= 0) {
            return index;
        } else {
            index = findBookByAuthor(bookDesc);
            if(index >= 0) {
                return index;
            } else {
                System.out.println(bookDesc + " was not found");
                return -1;
            }
        }
    }

    private int findBookByTitle(String title) {
        for(int i = 0; i < books.length; i++) {
            if(books[i].getTitle().equals(title)) {
                return i;
            }
        }
        return -1;
    }

    private int findBookByAuthor(String author) {
        for(int i = 0; i < books.length; i++) {
            if(books[i].getAuthor().equals(author)) {
                return i;
            }
        }
        return -1;
    }

    private void resizeArray() {
        Book[] largeArray = new Book[books.length * 2];
        for(int i = 0; i < numBooks; i++) {
            largeArray[i] = books[i];
        }
        books = largeArray;
    }

    public static void main(String[] args) {
        System.out.println("Welcome to the Ashbury Library Management System");
        Library library = new Library();

        Scanner input = new Scanner(System.in);
        boolean loggedIn = true;
        while(loggedIn) {
            library.printSelections();

            try {
                int choice = input.nextInt();
                if(choice < 1 || choice >7) throw new Exception();

                switch(choice) {
                    case 1:
                        library.checkout(); break;
                    case 2:
                        library.checkin(); break;
                    case 3:
                        library.getAvailability(); break;
                    case 4:
                        library.listBooks(); break;
                    case 5:
                        library.addNewBook(); break;
                    case 6:
                        library.deleteBook(); break;
                    case 7:
                        loggedIn = false;
                }
            } catch (Exception e) {
                System.err.println("Invalid Selection. Please try again");
                input.nextLine();
            } finally {
                library.save();
            }
        }

        System.out.println("Thank you for using ALMS");
    }
}
